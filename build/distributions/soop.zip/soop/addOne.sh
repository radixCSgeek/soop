#! /bin/bash
sleep 5
echo '!SOOP:$$val='$(($1 + 1))
echo another line